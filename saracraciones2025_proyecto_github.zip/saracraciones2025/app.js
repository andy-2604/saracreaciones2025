(() => {
  'use strict';
  const $ = (selector) => document.querySelector(selector);
  const getStore = (key, fallback) => { try { const val = localStorage.getItem(key); return val === null ? fallback : JSON.parse(val); } catch { return fallback; } };
  const saveStore = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} };
  const publicCatalog = Array.isArray(window.SARA_CATALOGO) ? window.SARA_CATALOGO : [];
  let items = getStore('sara_catalogo_borrador_v1', null);
  if (!Array.isArray(items)) items = publicCatalog;
  const publicConfig = window.SARA_CONFIG || {};
  const config = { ...publicConfig, ...getStore('sara_config_borrador_v1', {}) };
  let cart = getStore('sara_consulta_v1', []);
  if (!Array.isArray(cart)) cart = [];
  let type = 'producto';
  let category = 'Todas';
  let query = '';
  let sort = 'destacados';
  let currentItemId = null;
  let toastTimer;
  let previousFocus;
  const esc = (val) => String(val ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const validImage = (src) => { const s = String(src || '').trim(); return /^(https?:\/\/|assets\/|\.\/assets\/)/i.test(s) && !/[<>\n\r]/.test(s) ? s : 'assets/muestras/telas-apiladas.svg'; };
  const filtered = () => items.filter(p => p && p.tipo === type);
  const money = (price, unit) => (price === null || price === undefined || price === '' || !Number.isFinite(Number(price))) ? 'Consultar precio' : `${new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS', maximumFractionDigits: 0 }).format(Number(price))}<small> / ${esc(unit || 'unidad')}</small>`;
  const toast = (text) => { const el = $('#toast'); el.textContent = text; el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3500); };
  const count = () => cart.reduce((sum, item) => sum + (Number(item.cantidad) || 0), 0);

  function renderFilters() {
    const categories = ['Todas', ...new Set(filtered().map(p => String(p.categoria || 'Otros')))];
    if (!categories.includes(category)) category = 'Todas';
    $('#category-filters').innerHTML = categories.map(c => `<button type="button" class="filter-chip ${c === category ? 'active' : ''}" data-category="${esc(c)}" aria-pressed="${c === category}">${esc(c)}</button>`).join('');
  }
  function renderCatalog() {
    $('#count-productos').textContent = items.filter(p => p.tipo === 'producto').length;
    $('#count-telas').textContent = items.filter(p => p.tipo === 'tela').length;
    ['producto', 'tela'].forEach(t => {
      const tab = $(`#tab-${t}`);
      tab.classList.toggle('active', t === type);
      tab.setAttribute('aria-selected', String(t === type));
    });
    renderFilters();
    let list = filtered().filter(p => (category === 'Todas' || p.categoria === category) && `${p.nombre || ''} ${p.descripcion || ''} ${p.categoria || ''}`.toLocaleLowerCase('es').includes(query));
    list.sort((a,b) => sort === 'az' ? String(a.nombre).localeCompare(String(b.nombre),'es') : sort === 'za' ? String(b.nombre).localeCompare(String(a.nombre),'es') : Number(!!b.destacado) - Number(!!a.destacado));
    $('#product-grid').innerHTML = list.map(p => `<article class="product-card">
      <div class="card-image"><img src="${esc(validImage(p.imagen))}" alt="${p.muestra ? 'Ilustración de ejemplo: ' : 'Foto: '}${esc(p.nombre)}" loading="lazy"><span class="card-badge ${p.muestra ? 'demo' : ''}">${p.muestra ? 'Imagen ilustrativa' : esc(p.disponibilidad || 'Consultar')}</span></div>
      <div class="card-info"><span class="card-category">${esc(p.categoria || 'Otros')}</span><h3 class="card-title">${esc(p.nombre)}</h3><p class="card-description">${esc(p.descripcion || '')}</p><div class="card-lower"><span class="card-price">${money(p.precio,p.unidad)}</span><div class="card-actions"><button class="detail-btn" type="button" data-detail="${esc(p.id)}">Ver detalle</button><button class="add-btn" type="button" data-add="${esc(p.id)}">+ Consultar</button></div></div></div>
    </article>`).join('');
    $('#empty-state').hidden = list.length > 0;
    $('#demo-alert').hidden = !list.some(p => p.muestra);
  }
  function setTab(newType) {
    type = newType === 'tela' ? 'tela' : 'producto';
    category = 'Todas'; query = '';
    $('#catalog-search').value = '';
    renderCatalog();
  }
  function refreshCart() {
    cart = cart.filter(c => items.some(p => p.id === c.id) && Number(c.cantidad) > 0);
    saveStore('sara_consulta_v1', cart);
    $('#header-cart-count').textContent = count();
    $('#floating-count').textContent = count();
    $('#drawer-count').textContent = `(${count()})`;
    const root = $('#drawer-items');
    if (!cart.length) root.innerHTML = '<div class="drawer-empty"><span>♡</span><h3>Tu lista está vacía</h3><p>Explorá el catálogo y agregá los artículos que quieras consultar.</p></div>';
    else root.innerHTML = cart.map(c => { const p = items.find(p => p.id === c.id); if (!p) return ''; return `<div class="drawer-line"><img src="${esc(validImage(p.imagen))}" alt=""><div><h3>${esc(p.nombre)}</h3><small>${esc(p.tipo === 'tela' ? 'Tela' : 'Confección')} · ${esc(p.unidad || 'unidad')}</small><div class="quantity-row"><button class="qty-button" type="button" data-quantity="${esc(p.id)}" data-change="-1" aria-label="Quitar una unidad de ${esc(p.nombre)}">−</button><strong>${Number(c.cantidad)}</strong><button class="qty-button" type="button" data-quantity="${esc(p.id)}" data-change="1" aria-label="Agregar una unidad de ${esc(p.nombre)}">+</button></div></div><button class="remove-button" type="button" data-remove="${esc(p.id)}" aria-label="Quitar ${esc(p.nombre)}">×</button></div>`; }).join('');
    $('#send-consult').disabled = !cart.length;
    $('#copy-consult').disabled = !cart.length;
  }
  function addItem(id) {
    if (!items.some(p => p.id === id)) return;
    const existing = cart.find(c => c.id === id);
    if (existing) existing.cantidad += 1;
    else cart.push({id,cantidad:1});
    refreshCart(); toast('Agregado a tu lista de consulta ♡');
  }
  function message() {
    if (!cart.length) return '¡Hola! Quisiera recibir información sobre sus productos y telas. ¡Gracias!';
    const lines = ['¡Hola, Sara Creaciones! Quisiera consultar por estos artículos:', ''];
    cart.forEach(c => { const p = items.find(p => p.id === c.id); if (p) lines.push(`• ${p.nombre} — ${c.cantidad} ${c.cantidad > 1 ? (p.unidad === 'metro' ? 'metros' : 'unidades') : (p.unidad || 'unidad')}`); });
    lines.push('', '¿Podrían confirmarme precios, disponibilidad y opciones de entrega? ¡Muchas gracias!');
    return lines.join('\n');
  }
  function openWhatsApp() {
    const phone = String(config.whatsapp || '').replace(/\D/g,'');
    if (!phone) {
      window.prompt('Falta configurar el número de WhatsApp de la tienda. Podés copiar este mensaje de consulta:',message());
      return;
    }
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message())}`, '_blank', 'noopener,noreferrer');
  }
  async function copyMessage() {
    try { await navigator.clipboard.writeText(message()); toast('Mensaje copiado. Ahora podés enviarlo ♡'); }
    catch { window.prompt('Copiá este mensaje:',message()); }
  }
  function showOverlay(which) {
    previousFocus = document.activeElement;
    document.body.classList.add('locked');
    $('#overlay').hidden = false;
    $('#cart-drawer').classList.toggle('open', which === 'cart');
    $('#detail-modal').classList.toggle('open', which === 'detail');
    $('#cart-drawer').setAttribute('aria-hidden',String(which !== 'cart'));
    $('#detail-modal').setAttribute('aria-hidden',String(which !== 'detail'));
    if (which === 'cart') refreshCart();
    requestAnimationFrame(() => (which === 'cart' ? $('.drawer-header .close-button') : $('.detail-close')).focus());
  }
  function closeOverlay() {
    $('#overlay').hidden = true;
    document.body.classList.remove('locked');
    $('#cart-drawer').classList.remove('open');
    $('#detail-modal').classList.remove('open');
    $('#cart-drawer').setAttribute('aria-hidden','true');
    $('#detail-modal').setAttribute('aria-hidden','true');
    if (previousFocus && previousFocus.isConnected) previousFocus.focus();
  }
  function details(id) {
    const p = items.find(p => p.id === id); if (!p) return;
    currentItemId = id;
    $('#detail-content').innerHTML = `<div class="detail-layout"><img src="${esc(validImage(p.imagen))}" alt="${p.muestra ? 'Ilustración de ejemplo de ' : 'Foto de '}${esc(p.nombre)}"><div class="detail-copy"><span class="eyebrow">${esc(p.tipo === 'tela' ? 'TELAS EN VENTA' : 'PRODUCTOS CONFECCIONADOS')} · ${esc(p.categoria)}</span><h2>${esc(p.nombre)}</h2><p>${esc(p.descripcion || '')}</p><span class="card-price">${money(p.precio,p.unidad)}</span><span class="detail-status">${p.muestra ? 'Artículo de ejemplo · no disponible para comprar' : esc(p.disponibilidad || 'Consultá disponibilidad')}</span><button type="button" class="btn btn-primary" data-add="${esc(p.id)}">+ Agregar a mi consulta</button></div></div>`;
    showOverlay('detail');
  }
  function switchMenu(open) {
    $('#main-nav').classList.toggle('open',open);
    $('#mobile-menu').setAttribute('aria-expanded',String(open));
  }

  document.addEventListener('click', e => {
    const openType = e.target.closest('[data-open-type]');
    if (openType) { setTab(openType.dataset.openType); switchMenu(false); }
    const tab = e.target.closest('[data-tab]'); if (tab) setTab(tab.dataset.tab);
    const cat = e.target.closest('[data-category]'); if (cat) { category = cat.dataset.category; renderCatalog(); }
    const add = e.target.closest('[data-add]'); if (add) addItem(add.dataset.add);
    const detail = e.target.closest('[data-detail]'); if (detail) details(detail.dataset.detail);
    const action = e.target.closest('[data-action]'); if (action) {
      switch(action.dataset.action) {
        case 'open-cart': showOverlay('cart'); break;
        case 'close': closeOverlay(); break;
        case 'contact': openWhatsApp(); break;
      }
    }
    const qty = e.target.closest('[data-quantity]'); if (qty) { const match = cart.find(c => c.id === qty.dataset.quantity); if (match) match.cantidad += Number(qty.dataset.change); refreshCart(); }
    const remove = e.target.closest('[data-remove]'); if (remove) { cart = cart.filter(c => c.id !== remove.dataset.remove); refreshCart(); }
  });
  $('#overlay').addEventListener('click',closeOverlay);
  document.addEventListener('keydown',e => { if (e.key === 'Escape') { closeOverlay(); switchMenu(false); } });
  $('#mobile-menu').addEventListener('click',() => switchMenu(!$('#main-nav').classList.contains('open')));
  $('#catalog-search').addEventListener('input',e => { query = e.target.value.toLocaleLowerCase('es').trim(); renderCatalog(); });
  $('#catalog-sort').addEventListener('change',e => { sort = e.target.value; renderCatalog(); });
  $('#clear-filters').addEventListener('click',() => { category='Todas'; query=''; $('#catalog-search').value=''; renderCatalog(); });
  $('#send-consult').addEventListener('click',openWhatsApp);
  $('#copy-consult').addEventListener('click',copyMessage);
  $('#footer-year').textContent = new Date().getFullYear();
  if (/^https:\/\//.test(String(config.instagram || ''))) { $('#instagram-link').href = config.instagram; $('#instagram-link').hidden = false; }
  if (location.hash === '#telas') { setTab('tela'); }
  renderCatalog(); refreshCart();
})();
