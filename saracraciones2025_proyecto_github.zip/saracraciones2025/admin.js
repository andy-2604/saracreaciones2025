(() => {
  'use strict';
  const $ = s => document.querySelector(s);
  const original = Array.isArray(window.SARA_CATALOGO) ? window.SARA_CATALOGO : [];
  const originalConfig = window.SARA_CONFIG || {};
  const load = (key, backup) => { try { const raw=localStorage.getItem(key); return raw ? JSON.parse(raw) : backup; } catch { return backup; } };
  const store = (key,v) => { try { localStorage.setItem(key,JSON.stringify(v)); } catch {} };
  let catalog = load('sara_catalogo_borrador_v1', original);
  if (!Array.isArray(catalog)) catalog = original.slice();
  let config = {...originalConfig,...load('sara_config_borrador_v1',{})};
  let timer;
  const esc = s => String(s ?? '').replace(/[&<>"']/g,ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const src = s => /^(https?:\/\/|assets\/|\.\/assets\/)/.test(String(s || '')) ? s : 'assets/muestras/bolso.svg';
  function notice(s) { const t=$('#toast');t.textContent=s;t.classList.add('show');clearTimeout(timer);timer=setTimeout(()=>t.classList.remove('show'),3200); }
  function refresh() {
    $('#admin-articles').innerHTML = catalog.map(p => `<article class="admin-item"><img src="${esc(src(p.imagen))}" alt=""><div><strong>${esc(p.nombre)}</strong><small>${p.tipo === 'tela' ? 'Tela' : 'Confección'} · ${esc(p.categoria)}</small></div><div class="admin-item-actions"><button type="button" data-edit="${esc(p.id)}" title="Editar">Editar</button><button type="button" data-delete="${esc(p.id)}" title="Eliminar" aria-label="Eliminar ${esc(p.nombre)}">×</button></div></article>`).join('') || '<p class="admin-hint">No hay artículos. Agregá el primero con el formulario.</p>';
    const numTelas=catalog.filter(p => p.tipo === 'tela').length;
    $('#admin-count').textContent = `${catalog.length} artículos en total · ${catalog.length-numTelas} confecciones · ${numTelas} telas`;
    store('sara_catalogo_borrador_v1',catalog);
  }
  function resetForm() {
    $('#article-form').reset();
    $('#a-id').value='';
    $('#a-photo').value='assets/productos/';
    $('#photo-preview').src='assets/muestras/bolso.svg';
    $('#form-heading').textContent='Agregar un artículo';
    $('#save-item').textContent='Agregar artículo';
  }
  function edit(id) {
    const p=catalog.find(x=>x.id===id);if(!p)return;
    $('#a-id').value=p.id;
    $('#a-type').value=p.tipo;
    $('#a-category').value=p.categoria||'';
    $('#a-name').value=p.nombre||'';
    $('#a-description').value=p.descripcion||'';
    $('#a-price').value=p.precio===null || p.precio===undefined ? '' : p.precio;
    $('#a-unit').value=p.unidad||'unidad';
    $('#a-stock').value=p.disponibilidad||'Consultar stock';
    $('#a-photo').value=p.imagen||'';
    $('#a-featured').checked=!!p.destacado;
    $('#a-demo').checked=!!p.muestra;
    $('#photo-preview').src=src(p.imagen);
    $('#form-heading').textContent='Editar artículo';
    $('#save-item').textContent='Guardar cambios';
    window.scrollTo({top:$('.admin-layout').offsetTop-100,behavior:'smooth'});
    $('#a-name').focus();
  }
  $('#article-form').addEventListener('submit',e=>{
    e.preventDefault();
    const id=$('#a-id').value || `art-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,6)}`;
    const photo=$('#a-photo').value.trim();
    if(!/^(assets\/|https:\/\/|http:\/\/)/.test(photo)) { notice('Escribí una ruta assets/... o una URL https:// válida.');$('#a-photo').focus();return; }
    const raw=$('#a-price').value;
    const article={id,tipo:$('#a-type').value,nombre:$('#a-name').value.trim(),categoria:$('#a-category').value.trim(),descripcion:$('#a-description').value.trim(),imagen:photo,precio:raw==='' ? null : Number(raw),unidad:$('#a-unit').value,disponibilidad:$('#a-stock').value,destacado:$('#a-featured').checked,muestra:$('#a-demo').checked};
    const i=catalog.findIndex(p=>p.id===id);
    if (i>=0) catalog[i]=article; else catalog.unshift(article);
    refresh();resetForm();notice('Artículo guardado en el borrador ♡');
  });
  $('#admin-articles').addEventListener('click',e=>{
    const editButton=e.target.closest('[data-edit]');if(editButton)edit(editButton.dataset.edit);
    const deleteButton=e.target.closest('[data-delete]');if(deleteButton){
      const p=catalog.find(x=>x.id===deleteButton.dataset.delete);
      if(p && confirm(`¿Eliminar «${p.nombre}» del borrador?`)) { catalog=catalog.filter(x=>x.id!==p.id);refresh();notice('Artículo eliminado del borrador'); }
    }
  });
  $('#a-photo').addEventListener('input',e=>{ $('#photo-preview').src=src(e.target.value); });
  $('#photo-preview').addEventListener('error',e=>{ if(!e.target.src.endsWith('bolso.svg'))e.target.src='assets/muestras/bolso.svg'; });
  $('#cancel-edit').addEventListener('click',resetForm);
  $('#reset-demo').addEventListener('click',()=>{if(confirm('¿Descartar todos los cambios del borrador y restaurar el catálogo publicado?')) {catalog=JSON.parse(JSON.stringify(original));refresh();resetForm();notice('Se restauró el catálogo original');}});
  $('#c-whatsapp').value=config.whatsapp||'';
  $('#c-instagram').value=config.instagram||'';
  function saveConfig() {
    config.whatsapp=$('#c-whatsapp').value.replace(/\D/g,'');
    config.instagram=$('#c-instagram').value.trim();
    if (config.instagram && !/^https:\/\//.test(config.instagram)) {notice('Instagram debe empezar con https://');return false;}
    store('sara_config_borrador_v1',config);
    notice('Datos guardados en el borrador. Falta publicar los archivos.');
    return true;
  }
  $('#save-config').addEventListener('click',saveConfig);
  function download(filename, content) {
    const blob=new Blob([content],{type:'text/javascript;charset=utf-8'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
  }
  $('#export-catalog').addEventListener('click',()=>{
    const serialized='// Catálogo exportado desde administrar.html.\nwindow.SARA_CATALOGO = '+JSON.stringify(catalog,null,2)+';\n';
    download('catalogo.js',serialized);notice('Descargaste catalogo.js. Subilo a data/ en GitHub.');
  });
  $('#export-config').addEventListener('click',()=>{
    if(!saveConfig())return;
    download('config.js','// Configuración pública exportada desde administrar.html.\nwindow.SARA_CONFIG = '+JSON.stringify(config,null,2)+';\n');
    notice('Descargaste config.js. Reemplazalo en la carpeta principal.');
  });
  resetForm();refresh();
})();
