// Configuración pública de la tienda.
// WhatsApp: solo números con código de país. Ejemplo para Argentina: "54911XXXXXXXX".
// No escribas signos +, espacios ni datos privados aquí.
window.SARA_CONFIG = {
  nombre: "saracraciones2025",
  whatsapp: "",  // REEMPLAZAR por tu número real para activar el enlace directo
  instagram: ""  // Opcional: por ejemplo https://www.instagram.com/tu_usuario/
};
