# saracraciones2025 🌸

Tienda web para **Sara Creaciones 2025**, con el **logo original provisto**, dos secciones diferenciadas y catálogo editable:

- **Productos confeccionados:** bolsos, accesorios, hogar, decoración, etc.
- **Telas en venta:** algodón, poplín, lienzo, estampados, gabardina, etc.

La web incluye buscador, filtros por categorías, vista de cada artículo, precios opcionales en pesos argentinos, lista de consulta, mensaje prearmado para WhatsApp y diseño responsive para celulares.

> **IMPORTANTE:** Las ilustraciones y los artículos precargados son **ejemplos**, no representan stock real. Antes de compartir la web con clientes, agregá las fotos y los productos verdaderos y configurá tu WhatsApp.

## 1. Publicar gratis en GitHub Pages

1. Entrá a [github.com](https://github.com/) e iniciá sesión.
2. Creá un repositorio **público** nuevo. Nombre recomendado: `saracraciones2025`.
3. Descomprimí el archivo ZIP de este proyecto en tu computadora.
4. En el repositorio, elegí **Add file → Upload files** y subí **todo el contenido de la carpeta `saracraciones2025`**, respetando la estructura de carpetas. Importante: `index.html` debe quedar en la **raíz del repositorio**, no dentro de una carpeta extra.
5. Elegí **Commit changes**.
6. Entrá a **Settings → Pages**. En **Build and deployment**, elegí **Deploy from a branch** y **Branch: main / (root)**. Guardá.
7. GitHub mostrará una dirección parecida a `https://TU_USUARIO.github.io/saracraciones2025/` (el enlace exacto depende de tu cuenta).

GitHub Pages puede tardar unos minutos en actualizar después de cada cambio. No necesitás pagar alojamiento web ni instalar React, Node o una base de datos.

## 2. Agregar productos y telas (modo sencillo)

1. Abrí `administrar.html` en tu web. También podés ingresar desde el enlace **Administrar catálogo** del pie de página.
2. Elegí **Productos confeccionados** o **Telas en venta**.
3. Escribí el nombre, categoría, descripción, precio (opcional), unidad y disponibilidad.
4. En **Ruta de la foto**, escribí, por ejemplo: `assets/productos/bolso-floreado.jpg`.
5. Guardá el artículo. Podés repetir el proceso sin límite fijo.
6. Para publicar el catálogo, presioná **Descargar catálogo actualizado**. Se descargará `catalogo.js`.
7. En GitHub, subí las fotos a **`assets/productos/`** y reemplazá **`data/catalogo.js`** por el archivo descargado. Confirmá con **Commit changes**.

**Advertencia:** los cambios de `administrar.html` quedan guardados **solo en ese navegador** hasta que subas los archivos a GitHub. Si abrís la web en otro celular, los cambios aún no publicados no se verán. No uses el administrador para guardar información privada.

### Cómo reemplazar un archivo en GitHub

Podés entrar a su carpeta dentro de GitHub, abrir el archivo y usar el ícono de lápiz para editarlo manualmente. Si preferís reemplazarlo con el archivo descargado, eliminá el anterior y subí el nuevo con el mismo nombre y en la misma ruta, o actualizalo mediante el editor de archivos de GitHub.

### Cómo preparar fotos

- Usá fotos JPG, PNG o WebP de tus propios artículos.
- Recomendación: fotos cuadradas (aprox. 1000 × 1000 px), bien iluminadas.
- Usá nombres fáciles, sin espacios, tildes ni caracteres especiales: `bolso-rosa.jpg`, `tela-algodon-azul.webp`.
- Las rutas distinguen mayúsculas y minúsculas: `Bolso.jpg` y `bolso.jpg` no son iguales en GitHub Pages.
- En el editor, **desmarcá** la casilla «Es un artículo de demostración» para productos reales.

## 3. Configurar WhatsApp

1. Abrí `administrar.html` y completá tu número en **Datos de contacto**.
2. Escribí el número con código de país, **solo dígitos, sin + ni espacios**. Para un celular argentino suele utilizarse `549` + código de área + número.
3. Opcionalmente agregá tu enlace de Instagram, comenzando con `https://`.
4. Presioná **Descargar contacto actualizado**.
5. Reemplazá `config.js` en la raíz de tu repositorio de GitHub.

También podés editar `config.js` a mano:

```javascript
window.SARA_CONFIG = {
  nombre: "saracraciones2025",
  whatsapp: "54911XXXXXXXX", // CAMBIAR por el número de la tienda
  instagram: "https://www.instagram.com/usuario/" // Opcional
};
```

Hasta que se complete WhatsApp, la web permite ver o copiar la consulta, pero **no puede enviar el mensaje a un número específico**.

## 4. Organizar productos y telas

En el editor podés escribir las categorías que quieras, por ejemplo:

| Sección | Categorías posibles |
| --- | --- |
| Productos confeccionados | Bolsos, Almohadones, Accesorios, Hogar, Regalos |
| Telas en venta | Algodón, Poplín, Lienzo, Estampadas, Gabardina |

El sitio crea los filtros automáticamente. Una tela puede tener precio «por metro» y una confección «por unidad».

## 5. Archivos del proyecto

```text
saracraciones2025/
├── index.html                # Tienda para el público
├── administrar.html          # Editor de productos (local, sin servidor)
├── styles.css                # Diseño adaptable
├── app.js                    # Búsquedas, filtros, consulta y WhatsApp
├── admin.js                  # Funciones del editor
├── config.js                 # Teléfono y redes
├── data/
│   └── catalogo.js          # Lista de todos los artículos
├── assets/
│   ├── logo-sara.png        # Tu logo original
│   ├── productos/           # Colocá aquí tus fotos reales
│   └── muestras/            # Ilustraciones originales de ejemplo
└── README.md
```

## 6. Qué incluye y qué no

- ✅ Sitio estático, gratuito para alojar en GitHub Pages.
- ✅ Logo adjunto y estética inspirada en sus colores.
- ✅ Páginas para productos confeccionados y telas, dentro de un mismo catálogo filtrable.
- ✅ Búsqueda, categorías, detalles, precios, stock textual y lista de consultas.
- ✅ Edición de artículos desde el navegador y exportación a GitHub.
- ✅ WhatsApp con mensaje prearmado **después de configurar el número**.
- ❌ No incluye pagos online, carrito de compra con cobro ni reservas automáticas.
- ❌ No es un panel de administración online protegido con contraseña; GitHub Pages es alojamiento estático.
- ❌ No publica cambios automáticamente en el repositorio ni sube fotos desde el navegador.

Si más adelante necesitás **subir fotos y editar productos desde cualquier teléfono sin tocar GitHub**, habría que conectar un sistema de gestión de contenidos o una base de datos, con autenticación.

### Personalización del nombre

Se conservó el nombre de proyecto pedido, **`saracraciones2025`**, y se muestra **saracraciones2025** como identificador de la tienda. La palabra grande **Sara** acompaña el logo adjunto. Si querés cambiar también el nombre del repositorio, las rutas internas siguen funcionando porque son relativas.
